<?php

error_reporting(0);
if (isset($_POST['login'])) {
    $user = $_POST['username'];
    $pass =$_POST['password'];
    
    if ($user == 'azhari' AND $pass == '123') {
        header("Location: admin.php") ;
        
    } else {
        $salah = "<p style='color: red; text-align: center;'>username dan password salah</p>";
    }
}
?>


<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <title></title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Lilita+One&display=swap" rel="stylesheet">

        <link rel="stylesheet" href="style.css">
    </head>
    <style>
        
    </style>
    <body>
        <div class="container">
        
         <img src="https://i.ibb.co/BCyTrmK/1691637600832.png" alt="logo" width="200">
         <h4> Kelas XII MIPA 1</h4>
         <h1>SMAN 1 BAE</h1>
         <?php echo $salah; ?>
           <form action="" method="post">
            <div class="form-inpt">
                <input type="text" placeholder="username" name="username"><br><br>
                <input type="password" placeholder="password" name="password"><br>
            </div>
           </form>
            
            <button type="submit" name="login">Login</button>
        </div>
    </body>
    <footer>
        
    </footer>
</html>